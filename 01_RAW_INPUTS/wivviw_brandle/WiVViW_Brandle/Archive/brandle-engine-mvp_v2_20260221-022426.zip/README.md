# Brandle Engine MVP (v2 - dependency-fixed)

## Requirements
- Node.js LTS (recommended: Node 20)

## Install + Run
```bash
npm install
npm run dev
```

Open: http://localhost:3000
